package br.com.vianajovi.todolist.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
@RequestMapping("/primeiraRota")

//http://localhost:8080 -- Rota
public class PrimeiraController {
    /**
     * Métodos de acesso HTTP:
     * GET- 'PEGA informações'
     * POST - 'Adiciona informações'
     * PUT - 'Altera informações'
     * DELETE - 'Deleta informações'
     * PATCH - 'Altera somente uma parte da informação'
     * 
     */

     // Método de uma classe
     @GetMapping ("/")
    public String firstMessage(){
        return "Done";
    }
}
